collapse <- function(x){
  paste("[", paste0(x, collapse = ", "), "]")
}